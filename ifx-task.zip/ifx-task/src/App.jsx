 import Navbar from "./components/navbar/navbar";
 import Content from "./components/mainContent/content";
import Footer from "./components/footer/footer";

 
 const App = () => {
  return(
    <div className="App">
      <Navbar />
      <Content />
      <Footer/>
    </div>
  ) 
  
};

export default App;
