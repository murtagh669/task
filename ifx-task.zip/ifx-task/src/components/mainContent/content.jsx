import React, { useState, useEffect } from "react";
import FlexboxComponent from "../flexboxComponent/flexboxComponent";
import "./content.css";

const Content = () => {
  const [fontSize, setFontSize] = useState(100);
  const [message, setMessage] = useState("");
  const [isVisible, setIsVisible] = useState(true);

  useEffect(() => {
    const savedFontSize = localStorage.getItem("fontSize");
    if (savedFontSize) {
      setFontSize(parseInt(savedFontSize));
    }
  }, []);

  const decreaseFontSize = () => {
    if (fontSize > 75) {
      setFontSize(fontSize - 5);
      localStorage.setItem("fontSize", fontSize - 5);
    } else {
      showMessage("osiągnięto limit!!!!");
    }
  };

  const increaseFontSize = () => {
    if (fontSize < 125) {
      setFontSize(fontSize + 5);
      localStorage.setItem("fontSize", fontSize + 5);
    } else {
      showMessage("osiągnięto limit!!!");
    }
  };

  const showMessage = (msg) => {
    setMessage(msg);
    setTimeout(() => {
      setMessage("");
    }, 5000);
  };

  const handleClose = () => {
    setIsVisible(false);
  };

  return (
    <>
      <main className="content">
        <div style={{ fontSize: `${fontSize}%` }}>
          <FlexboxComponent />
        </div>
        {isVisible && (
        <>
          <div class="button-container">
            <div class="border">
            <span class="info-font"> Font size: {fontSize}% </span>
              <button onClick={decreaseFontSize}>-</button>
              <button onClick={increaseFontSize}>+</button>
              <button onClick={handleClose} class="close-btn">
                &times;
              </button>
            </div>
          </div>
          <h1 class="alert-info">{message} </h1>
        </>
      )}
      </main>
      
    </>
  );
};

export default Content;
