import React from 'react';
import { render, fireEvent, screen } from '@testing-library/react';
import Content from './content';

describe('Content component', () => {
  test('renders with initial font size and buttons', () => {
    render(<Content />);

    const decreaseButton = screen.getByText('-');
    const increaseButton = screen.getByText('+');
    const closeButton = screen.getByText('×');

    expect(decreaseButton).toBeInTheDocument();
    expect(increaseButton).toBeInTheDocument();
    expect(closeButton).toBeInTheDocument();
  });

  test('decreases font size on "-" button click', () => {
    render(<Content />);

    const decreaseButton = screen.getByText('-');
    fireEvent.click(decreaseButton);

    const fontSizeInfo = screen.getByText('Font size: 95%');
    expect(fontSizeInfo).toBeInTheDocument();
  });

  test('closes content on "×" button click', () => {
    render(<Content />);

    const closeButton = screen.getByText('×');
    fireEvent.click(closeButton);

    const content = screen.queryByTestId('content');
    expect(content).toBeNull();
  });


});
