import "./footer.css";
const Footer = () => (
  <footer className="footer">
    <p>&copy; Copyright 2024, Mateusz Sorys for IFX</p>
  </footer>
);

export default Footer;
