import React from "react";
import "./flexboxComponent.styles.css";

const FlexboxComponent = () => {
  return (
    <>
      <div className="container">
        <div className="left-column">
          <div className="image-container">
            <img
              className="image"
              src=" https://i.pravatar.cc/"
              alt="Opis obrazka"
            />
            <div className="image-text">Lorem ipsum dolor sit amet</div>
          </div>
        </div>
        <div className="right-column">
          <div className="item">
            <h4>Title 1</h4>

            <div className="card">
              <img
                src=" https://i.pravatar.cc/150?img=2"
                alt="Alternative"
                className="photo"
              />
              <div className="text">
                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam
                sit amet porta tellus, ut mattis nisl. Maecenas et tortor
                feugiat, suscipit ligula sit amet, ornare nisl.
              </div>
            </div>
          </div>
          <div className="item">
            <h4>Title 1</h4>

            <div className="card">
              <img
                src=" https://i.pravatar.cc/150?img=2"
                alt="Alternative"
                className="photo"
              />
              <div className="text">
                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam
                sit amet porta tellus, ut mattis nisl. Maecenas et tortor
                feugiat, suscipit ligula sit amet, ornare nisl.
              </div>
            </div>
          </div>
          <div className="item">
            <h4>Title 1</h4>

            <div className="card">
              <img
                src=" https://i.pravatar.cc/150?img=2"
                alt="Alternative"
                className="photo"
              />
              <div className="text">
                Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam
                sit amet porta tellus, ut mattis nisl. Maecenas et tortor
                feugiat, suscipit ligula sit amet, ornare nisl.
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="row">
        <div className="column">
          <div className="column-container">
            <div className="top"></div>
            <div className="bottom">
              <p>Your text goes here.</p>
            </div>
          </div>
        </div>
        <div className="column">
          <div className="column-container">
            <div className="top"></div>
            <div className="bottom">
              <p>Your text goes here.</p>
            </div>
          </div>
        </div>
        <div className="column">
          <h4>Title 1</h4>

          <div className="card">
            <img
              src=" https://i.pravatar.cc/150?img=2"
              alt="Alternative"
              className="photo"
            />
            <div className="text">
              Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam sit
              amet porta tellus, ut mattis nisl. Maecenas et tortor feugiat,
              suscipit ligula sit amet, ornare nisl.
            </div>
          </div>
        </div>
      </div>
    </>
  );
};

export default FlexboxComponent;
