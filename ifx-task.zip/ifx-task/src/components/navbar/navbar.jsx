import React, { useState, useEffect } from 'react';
import './navbar.css';
import Logo from '../../assets/logo.svg';

const Navbar = () => {
  const [scrolled, setScrolled] = useState(false);

  const handleScroll = () => {
    const offset = window.scrollY;
    setScrolled(offset > 200);
  };

  useEffect(() => {
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const navbarClasses = ['navbar', scrolled ? 'scrolled' : ''].join(' ');

  return (
    <header className={navbarClasses}>
      <div className="logo">
        <img src={Logo} alt="Logo" title="Logo" />
      </div>

      <nav className="navigation">
        <ul>
          <li><a href="#post1">Home</a></li>
          <li><a href="#post2">Home</a></li>
          <li><a href="#post3">Home</a></li>
          <li><a href="#post4">Home</a></li>
        </ul>
      </nav>
    </header>
  );
};

export default Navbar;
